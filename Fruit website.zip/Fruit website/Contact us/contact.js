const button = document.querySelector(".login-btn");
button.addEventListener("click", function () {
  // Redirect to the other page
  console.log("hjj");
  window.location.href = "/login/login.html";
});
